/*
配置处理类
 */
package Common

import (
	"github.com/json-iterator/go"
	"os"
	"encoding/json"
	"os/exec"
	"path/filepath"
	"github.com/landjur/golibrary/log"
	"fmt"
	"strings"
	"unsafe"
	"github.com/suiyunonghen/DxTcpServer"
	"errors"
)

type(
	NetTransConfig struct {
		ServerAddr		string	//本地端口：8923
	}


	DbConfig struct {
		DbDriver		string			//数据库类型
		Server			string
		Port			string
		User			string
		Pwd				string
		DbName			string
	}

	PkgType			byte

	XtServiceConfig struct {
		Http		NetTransConfig
		Tcp		NetTransConfig
		WebSocket       NetTransConfig
		DataBase 	[]DbConfig
		//HospitalId  string			//医院ID
		DebugLog	bool			//是否启用调试日志
	}

)

const(
	RP_Method		PkgType=iota //方法包
	RP_Result					//结果包
	RP_Notify					//通知包
)

var(
	ServiceConfig  XtServiceConfig
	AppFileName		string
	AppPath			string
	ServerStartTime	string
	ErrTimeOut		error = errors.New("执行操作超时！")
	bufferWriter	*DxTcpServer.BufferLoggerWriter
	Logger			*log.Logger
	Quit			chan struct{}
)

func (cfg *XtServiceConfig)HttpPort()string  {
	if cfg.Http.ServerAddr != ""{
		idx := strings.IndexByte(cfg.Http.ServerAddr,':')
		if idx != -1{
			return string([]byte(cfg.Http.ServerAddr)[idx:])
		}
	}
	return ""
}


func ParseConfig(cfgfile string,cfgdata interface{})error  {
	finfo,err := os.Stat(cfgfile)
	if err == nil && !finfo.IsDir() {
		var file *os.File
		file,err = os.Open(cfgfile)
		if err == nil{
			databytes := make([]byte,finfo.Size())
			file.Read(databytes)
			//UTF8编码的
			if databytes[0] == 0xEF && databytes[1] == 0xBB && databytes[2] == 0xBF{
				databytes = databytes[3:]
			}
			err = jsoniter.Unmarshal(databytes,cfgdata)
		}
	}
	return err
}

func WriteConfig(cfgfile string,cfgdata interface{})  {
	if file,err := os.OpenFile(cfgfile,os.O_CREATE | os.O_TRUNC,0644);err == nil{
		if databytes,err := json.Marshal(cfgdata);err == nil{
			file.Write(databytes)
			file.Close()
		}
	}
}

func FastByte2String(bt []byte)string  {
	return *(*string)(unsafe.Pointer(&bt))
}


func FastString2Byte(str string)[]byte  {
	return *(*[]byte)(unsafe.Pointer(&str))
}

func Bool2Str(b bool)string  {
	if b{
		return "true"
	}else{
		return "false"
	}
}

func DebuginfoLog(LogTag string,LogMsg...interface{}){
	if Logger!=nil{
		Logger.SetPrefix(LogTag)
		Logger.Debugln(LogMsg)
	}
}

func CloseLog()  {
	if bufferWriter != nil{
		bufferWriter.QuitWriter()
	}
}

func init()  {
	Quit = make(chan struct{})
	AppFileName,_ = exec.LookPath(os.Args[0])
	AppPath = filepath.Dir(AppFileName)
	cfgFile := fmt.Sprintf("%s%s",AppPath,"\\Service.cfg") //读取系统配置
	ParseConfig(cfgFile,&ServiceConfig)
	if ServiceConfig.DebugLog{ //启用调试日志
		bufferWriter = DxTcpServer.NewLoggerBufferWriter()
		Logger = log.NewLogger(bufferWriter,"[Debug]")
		go bufferWriter.WriteData2File() //执行异步写入文件的检查
	}
}