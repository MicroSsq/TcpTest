package Common



type  WebSocMsgPack struct{
	MsgType string
	MsgContext interface{}
	BakContext interface{}
	YsInfo interface{}
}
