package DBOperate

import (
	_ "github.com/denisenkom/go-mssqldb"
	//_"github.com/mattn/go-adodb"
	"GoFbCenter/Common"
	"database/sql"
	"fmt"
	"github.com/landjur/golibrary/errors"
	"reflect"
	"bytes"
	"time"
	"encoding/base64"
	_"github.com/go-ole/go-ole"
)


type(
	DataBases struct {
		dbs				map[string]*sql.DB
	}
)

var(
	DbOp		*DataBases
	DBNoExistsError error = errors.New("数据库不存在")
	mainDbName		string			//主数据库，第一个数据库名
)

func (dbop *DataBases)Open()  {
	if Common.ServiceConfig.DataBase == nil{
		return
	}
	for _,dbcfg := range Common.ServiceConfig.DataBase{
		if dbcfg.DbDriver == "sql server" || dbcfg.DbDriver == "sqlserver"{
			/*server := dbcfg.Server
			if dbcfg.Port != ""{
				server = fmt.Sprintf("%s,%s",server,dbcfg.Port)
			}
			connString := fmt.Sprintf("Provider=SQLOLEDB.1;Password=%s;Persist Security Info=True;User ID=%s;Initial Catalog=%s;Data Source=%s",
				dbcfg.Pwd,dbcfg.User,dbcfg.DbName,server)
			db, _ := sql.Open("adodb", connString)*/

			db,_ := sql.Open("mssql", fmt.Sprintf("encrypt=disable;server=%s;user id=%s;password=%s;port=%s;database=%s", dbcfg.Server, dbcfg.User, dbcfg.Pwd, dbcfg.Port,dbcfg.DbName))
			err := db.Ping()
			if err==nil{
				dbop.dbs[dbcfg.DbName] = db
				if mainDbName == ""{
					mainDbName = dbcfg.DbName
				}
			}else{
				Common.DebuginfoLog("[Error]",fmt.Sprintf("连接数据库%s失败：%v",dbcfg.DbName,err))

			}
		}
	}
}

func (dbop *DataBases)Close()  {
	for _,v := range dbop.dbs{
		v.Close()
	}
}

func (dbop *DataBases)GetSqlValue(asql,DbName string)(map[string]interface{},error) {
	if DbName == ""{
		DbName = mainDbName
	}
	if db,ok := dbop.dbs[DbName];ok{
		if rows,err := db.Query(asql);err == nil{
			defer rows.Close()
			if rows.Next(){
				flds,_ := rows.Columns()
				fldtpes,_ := rows.ColumnTypes()
				result := make(map[string]interface{},len(flds))
				scanArgs := make([]interface{},len(flds))
				values := make([]interface{}, len(scanArgs))
				for idx,fldtype := range fldtpes{
					fldtype := fldtype.ScanType()
					switch fldtype.Kind() {
					case  reflect.String:
						values[idx] = ""
					case reflect.Bool:
						values[idx] = false
					case reflect.Int,reflect.Int8,reflect.Int16,reflect.Int32:
						values[idx] = int(0)
					case reflect.Uint,reflect.Uint8,reflect.Uint16,reflect.Uint32:
						values[idx] = uint(0)
					case reflect.Int64:
						values[idx] = int64(0)
					case reflect.Uint64:
						values[idx] = uint64(0)
					case reflect.Float32:
						values[idx] = float32(0)
					case reflect.Float64:
						values[idx] = float64(0)
					case reflect.Struct:
						switch fldtype.Name() {
						case "Time":
							values[idx] = time.Now()
						case "Int"://big.Int
							values[idx] = int64(0)
						case "SafeArray":
							values[idx] = make([]byte,0,100)
						default:
							fmt.Println(fldtype.Name())

						}
					case reflect.Ptr:
						fldtype = fldtype.Elem()
						switch fldtype.Kind() {
						case reflect.Struct:
							switch fldtype.Name() {
							case "Time":
								values[idx] = time.Now()
							case "Int"://big.Int
								values[idx] = reflect.New(fldtype).Interface() //int64(0)
							case "SafeArray":
								values[idx] = make([]byte,0,100)
							}
						}
					default:
						values[idx] = make([]byte,0,100)
					}
					scanArgs[idx] = &values[idx]
				}
				if err =rows.Scan(scanArgs...);err!=nil{
					return nil,err
				}
				for idx,_ := range scanArgs{
					if values[idx] != nil{
						result[flds[idx]] = values[idx]
					}else{
						result[flds[idx]] = nil
					}
				}
				return result,nil
			}
			return nil,nil
		}else{
			return nil,err
		}
	}
	return nil,DBNoExistsError
}


//查询一个语句，转化到Json结构格式
/*结构
{DataField:[F1,F2,F3],
Data:[
[V1,V2,V3],
[V1,V2,V3]]}
*/
func (dbop *DataBases)DataSet2Json(asql,DbName string)(string,error) {
	if DbName == ""{
		DbName = mainDbName
	}
	if db,ok := dbop.dbs[DbName];ok {
		if rows, err := db.Query(asql); err == nil && rows !=nil {
			defer rows.Close()
			btt := make([]byte,0,5000)
			buffer := bytes.NewBuffer(btt)
			flds,_ := rows.Columns()
			buffer.WriteString(`{"DataField":[`)
			for idx,fld := range flds{
				if idx > 0{
					buffer.WriteByte(',')
				}
				buffer.WriteByte('"')
				buffer.WriteString(fld)
				buffer.WriteByte('"')
			}
			fldtpes,err := rows.ColumnTypes()
			if err != nil {
				fmt.Println("error:",err)
				return "",err
			}
			scanArgs := make([]interface{},len(flds))
			values := make([]interface{}, len(scanArgs))
			for idx,fldtype := range fldtpes{
				ftype := fldtype.ScanType()
				switch ftype.Kind() {
				case  reflect.String:
					values[idx] = ""
				case reflect.Bool:
					values[idx] = false
				case reflect.Int,reflect.Int8,reflect.Int16,reflect.Int32:
					values[idx] = int(0)
				case reflect.Uint,reflect.Uint8,reflect.Uint16,reflect.Uint32:
					values[idx] = uint(0)
				case reflect.Int64:
					values[idx] = int64(0)
				case reflect.Uint64:
					values[idx] = uint64(0)
				case reflect.Float32:
					values[idx] = float32(0)
				case reflect.Float64:
					values[idx] = float64(0)
				case reflect.Struct:
					switch ftype.Name() {
					case "Time":
						values[idx] = time.Now()
					case "Int"://big.Int
						values[idx] = int64(0)
					case "SafeArray":
						values[idx] = make([]byte,0,100)
					default:
						fmt.Println(ftype.Name())

					}
				case reflect.Ptr:
					ftype = ftype.Elem()
					switch ftype.Kind() {
					case reflect.Struct:
						switch ftype.Name() {
						case "Time":
							values[idx] = time.Now()
						case "Int"://big.Int
							values[idx] = int64(0)
						case "SafeArray":
							values[idx] = make([]byte,0,512)
						}
					}
				default:
					values[idx] = make([]byte,0,512)
				}
				scanArgs[idx] = &values[idx]
			}
			buffer.WriteString(`],"Data":[`)
			isfirst:=true
			for rows.Next(){
				if err =rows.Scan(scanArgs...);err!=nil{
					return "",err
				}
				if isfirst{
					buffer.WriteString(`[`)
					isfirst = false
				}else{
					buffer.WriteString(`,[`)
				}
				for idx,_ := range scanArgs{
					if idx > 0{
						buffer.WriteByte(',')
					}
					v := values[idx]
					if v == nil{
						buffer.WriteString("null")
					}else{
						ftype := fldtpes[idx].ScanType()
						if ftype.Kind() == reflect.Ptr{
							ftype = ftype.Elem()
						}
						switch ftype.Kind() {
						case  reflect.String:
							buffer.WriteByte('"')
							buffer.WriteString(v.(string))
							buffer.WriteByte('"')
						case reflect.Bool:
							buffer.WriteString(Common.Bool2Str(v.(bool)))
						case reflect.Int,reflect.Int8,reflect.Int16,reflect.Int32,
							reflect.Uint,reflect.Uint8,reflect.Uint16,reflect.Uint32,
							reflect.Int64,reflect.Uint64,reflect.Float32,reflect.Float64:
							buffer.WriteString(fmt.Sprintf("%v",v))
						case reflect.Struct:
							switch ftype.Name() {
							case "Time":
								buffer.WriteByte('"')
								buffer.WriteString(v.(time.Time).Format("2006-01-02 15:04:05"))
								buffer.WriteByte('"')
							case "Int":
								buffer.WriteString(fmt.Sprintf("%v",v))
							case "SafeArray":
								buffer.WriteString(`{"Blob":"`)
								var dst []byte
								switch values[idx].(type) {
								case []uint8:
									l := base64.StdEncoding.EncodedLen(len(v.([]uint8)))
									dst = make([]byte,l)
									base64.RawStdEncoding.Encode(dst,([]byte)(v.([]uint8)))
								default:
									l := base64.StdEncoding.EncodedLen(len(v.([]byte)))
									dst = make([]byte,l)
									base64.StdEncoding.Encode(dst,v.([]byte))
								}
								buffer.Write(dst)
								buffer.WriteString(`"}`)
							}
						default:
							//二进制，使用Base64编码
							buffer.WriteString(`{"Blob":"`)
							l := base64.StdEncoding.EncodedLen(len(v.([]byte)))
							dst := make([]byte,l)
							base64.StdEncoding.Encode(dst,v.([]byte))
							buffer.Write(dst)
							buffer.WriteString(`"}`)
						}
					}
				}
				buffer.WriteString(`]`)
			}
			buffer.WriteString("]}")
			return Common.FastByte2String(buffer.Bytes()),nil
		}else{
			return "",err
		}
	}
	return "",DBNoExistsError
}

func (dbop *DataBases) ExecuteSql(asql,DbName string,args ...interface{})error {
	if DbName == ""{
		DbName = mainDbName
	}
	if db,ok := dbop.dbs[DbName];ok {
		if _,err := db.Exec(asql,args);err != nil{
			return err
		}
		return nil
	}
	return DBNoExistsError
}

func NewDbOp()*DataBases  {
	ret := new(DataBases)
	ret.dbs = make(map[string]*sql.DB,5)
	return ret
}