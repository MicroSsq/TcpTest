package TcpService

import (
	"github.com/suiyunonghen/DxTcpServer"
	"github.com/json-iterator/go"
	"sync"
	"GoFbCenter/Common"
	"github.com/landjur/golibrary/uuid"
	"time"
	"bytes"
	"fmt"
	"io"
)

type (

	MethodHandler func(con *DxTcpServer.DxNetConnection, methodPkg *TcpMethod)
	MethodPkg struct {
		Name		string
		ID 			string
		Params		map[string]interface{}
	}

	//用户
	AppUser struct {
		UserId					string
		Name					string
		Ks						string
		Zc                      string
		LastLogintime 		    string  //最后登录时间
		con						*DxTcpServer.DxNetConnection
	}


	////客户端
	//ClientUser struct {
	//	HostID			string
	//	Name			string
	//	OnLineUser		map[string]string				//在线的医生信息,  医生ID：医生名称
	//	con				*DxTcpServer.DxNetConnection
	//}



	MethodResult struct {
		Value		interface{}
		Err			string
	}
	TcpMethod  struct {
		Type		Common.PkgType				//包类型
		Method		MethodPkg
		Result 		MethodResult
		fWaitchan	chan struct{}		//等待的通道
		fWriteBack	bool						//是否回写回去
	}

	TcpService struct {
		DxTcpServer.DxTcpServer
		fExeWaitMethods			map[string]*TcpMethod	//ExecuteWait正在执行等待的方法
		fmethods				map[string]MethodHandler	 //客户请求的方法处理
		fResultMethods			map[string]MethodHandler	 //自己请求的方法的返回结果
	}

	IEncoder interface {
		Encode(v interface{}) error
	}

	IDecoder interface {
		Decode(v interface{}) error
	}

	CmdCoder struct {}
)



var(
	pkgpool sync.Pool
	AppUsers				map[string]*AppUser	//血糖用户组
	//DocList				map[string]*HospitalClient
	GlobalMutx				sync.RWMutex
)

func (mnd *TcpMethod)ReSet()  {
	mnd.Method.Name = ""
	mnd.Method.ID = ""
	mnd.Type = Common.RP_Method
	mnd.Method.Params = nil
	mnd.Result.Value = nil
	mnd.fWriteBack = true
	mnd.Result.Err = ""
	if mnd.fWaitchan != nil{
		close(mnd.fWaitchan)
		mnd.fWaitchan = nil
	}
}


func getMethod(methodName string,methodPkg Common.PkgType, createMethodId bool)*TcpMethod  {
	methodid := ""
	if createMethodId{
		if uid,err := uuid.NewV4();err==nil{
			methodid = uid.String()
		}else{
			return nil
		}
	}
	result := pkgpool.Get()
	var method *TcpMethod
	if result == nil {
		method = new(TcpMethod)
	}else{
		method = result.(*TcpMethod)
	}
	method.Type = methodPkg
	method.Method.ID = methodid
	method.Method.Name = methodName
	method.fWriteBack = true
	return method
}

func freeMethod(method *TcpMethod)  {
	method.ReSet()
	pkgpool.Put(method)
}


//命令编码规则
func (coder *CmdCoder)Encode(obj interface{},buf io.Writer) error {
	encoder := jsoniter.NewEncoder(buf)
	return encoder.Encode(obj)
}

func (coder *CmdCoder)Decode(pkgbytes []byte)(result interface{},ok bool)  {
	buf := bytes.NewReader(pkgbytes[:])
	decoder := jsoniter.NewDecoder(buf)
	methodpkg := getMethod("",Common.RP_Method,false)
	ok = decoder.Decode(methodpkg) == nil
	if ok{
		result = methodpkg
	}else{
		result = nil
		freeMethod(methodpkg)
	}
	return
}

func (coder *CmdCoder)HeadBufferLen()uint16  {
	return 2
}

func (coder *CmdCoder)MaxBufferLen()uint16  {
	return 10*1460
}

func (coder *CmdCoder)UseLitterEndian()bool  {
	return false
}

func (srv *TcpService)ExecuteMethod(con *DxTcpServer.DxNetConnection,MethodName string,Params map[string]interface{})  {
	method := getMethod(MethodName,Common.RP_Method,true)
	if method == nil{
		return
	}
	method.Method.Params = Params
	con.WriteObject(method)
}

func (srv *TcpService)ExecuteWait(con *DxTcpServer.DxNetConnection,MethodName string,Params map[string]interface{},WaitTime int32)  {
	method := getMethod(MethodName,Common.RP_Method,true)
	if method == nil{
		return
	}
	if WaitTime<=0{
		WaitTime = 5000
	}
	defer freeMethod(method)
	method.Method.Params = Params
	method.fWaitchan = make(chan struct{})
	srv.Lock()
	srv.fExeWaitMethods[method.Method.ID] = method
	srv.Unlock()
	con.WriteObject(method)
	for{
		select {
		case <-method.fWaitchan:
			//返回了
			return
		case <-Common.Quit:
			return
		case <-DxTcpServer.After(time.Millisecond * time.Duration(WaitTime)):
			//超时了
			srv.Lock()
			delete(srv.fExeWaitMethods,method.Method.ID)
			srv.Unlock()
			return
		}
	}
}





func (srv *TcpService)userclientLogin(con *DxTcpServer.DxNetConnection, methodPkg *TcpMethod){
	if _,ok := methodPkg.Method.Params["Station"];!ok{
		methodPkg.Method.Params = nil
		methodPkg.Result.Err = "无效的登录站点"
		return
	}
	if uid,ok := methodPkg.Method.Params["logininfo"];ok{
		var UserId,Name,Ks,Zc string
		var mp map[string]interface{}
		jsoniter.Unmarshal([]byte(uid.(string)),&mp)
		if v,ok := methodPkg.Method.Params["UserId"];ok{
			UserId = v.(string)
		}
		if v,ok := methodPkg.Method.Params["Name"];ok{
			Name = v.(string)
		}
		if v,ok := methodPkg.Method.Params["Ks"];ok{
			Ks = v.(string)
		}
		if v,ok := methodPkg.Method.Params["Zc"];ok{
			Zc = v.(string)
		}
		if UserId == "" || Name == ""{
			methodPkg.Method.Params = nil
			methodPkg.Result.Err = "无效的登录请求信息"
			return
		}else {
			var client *AppUser
			GlobalMutx.Lock()
			if oldhostclient,ok := AppUsers[UserId];ok{
				//工号和站点一致则更新最后登录时间
				if oldhostclient.Ks == Ks{
					oldhostclient.LastLogintime = time.Now().Format("2006-01-02 15:04:05")
				}
			}else{
				client = new(AppUser)
				client.LastLogintime = time.Now().Format("2006-01-02 15:04:05")
				client.Ks = Ks
				client.Name = Name
				client.UserId = UserId
				client.Zc = Zc

			}
			methodPkg.Method.Params = nil
			methodPkg.Result.Value = "登录成功！"
			methodPkg.Result.Err = ""
		}
	}else{
		methodPkg.Method.Params = nil
		methodPkg.Result.Err = "无效的登录请求信息"
		return
	}

	/*
	IsHostpital := ok
	ID := ""
	if uid,ok := methodPkg.Method.Params["UID"];ok{
		ID = uid.(string)
	}else{
		methodPkg.Method.Params = nil
		methodPkg.Result.Err = "无效的登录请求信息"
		return
	}
	if IsHostpital{ //医院登录
		var oldhostclient,hostclient *HospitalClient
		GlobalMutx.Lock()
		if oldhostclient,ok = Hospitals[ID];ok{
			if oldhostclient.con != nil && oldhostclient.con != con{
				//通知上一个连接，其他人登录
				hostclient = new(HospitalClient)
				hostclient.Name = oldhostclient.Name
				hostclient.OnLineUser = make(map[string]string,100) //100个默认的医生容量
				//将以前的在线信息，复制到这个连接上来
				for k,v := range oldhostclient.OnLineUser {
					hostclient.OnLineUser[k] = v
				}
				mnd := getMethod("OtherClientLogin",Common.RP_Notify,true)
				oldhostclient.con.WriteObject(mnd)
				Hospitals[ID] = hostclient//指向新连接
			}
		}else {
			//读取医院信息
			ret,err := DBOperate.DbOp.GetSqlValue(fmt.Sprintf("select H_Hospital from T1_hospital where H_HospitalID='%s'",ID),"fbxt_fzjh")
			if err==nil{
				if ret==nil{
					//用户不存在
					GlobalMutx.Unlock()
					methodPkg.Method.Params = nil
					methodPkg.Result.Err = "无效的用户"
					return
				}
			}else{
				GlobalMutx.Unlock()
				methodPkg.Method.Params = nil
				methodPkg.Result.Err = fmt.Sprintf("执行发生错误：%s",err.Error())
				return
			}
			hostclient = new(HospitalClient)
			hostclient.OnLineUser = make(map[string]string,100) //100个默认的医生容量
			hostclient.Name = ret["H_Hospital"].(string)
			Hospitals[ID] = hostclient
		}
		hostclient.con = con
		hostclient.HostID = ID
		con.SetUseData(hostclient)
		GlobalMutx.Unlock()
		//返回
		methodPkg.Method.Params = nil
		methodPkg.Result.Value = hostclient.Name //返回医院名称
		methodPkg.Result.Err = ""
	}else{//APP登录
		phonebyte,ok := methodPkg.Method.Params["PhoneNum"]
		if !ok{
			methodPkg.Method.Params = nil
			methodPkg.Result.Err = "请指定登录的手机号码"
			return
		}
		var Appclient *XtAppUser
		Phone := Common.FastByte2String(phonebyte.([]byte))
		GlobalMutx.Lock()
		if oldAppClient,ok := AppUsers[Phone];ok && oldAppClient.UserId == ID{
			if oldAppClient.con != nil && oldAppClient.con != con{
				Appclient = new(XtAppUser)
				Appclient.Name = oldAppClient.Name
				Appclient.PWd = oldAppClient.PWd
				Appclient.UserId = oldAppClient.UserId
				mnd := getMethod("OtherClientLogin",Common.RP_Notify,true) //通知
				oldAppClient.con.WriteObject(mnd)
				AppUsers[ID] = Appclient//指向新连接
				Appclient.con = con
				con.SetUseData(Appclient)
				GlobalMutx.Unlock()
				methodPkg.Method.Params = nil
				methodPkg.Result.Err = ""
				methodPkg.Result.Value = 0
			}else{
				con.SetUseData(oldAppClient)
				GlobalMutx.Unlock()
				methodPkg.Method.Params = nil
				methodPkg.Result.Err = ""
				methodPkg.Result.Value = 0
			}
		}else{
			GlobalMutx.Unlock()
			methodPkg.Method.Params = nil
			methodPkg.Result.Err = "无效的用户"
			return
		}
	}
	*/
}


func registerMethods(srv *TcpService)  {
	//方法
}



func InitService()*TcpService  {
	srv := new(TcpService)

	srv.fmethods = make(map[string]MethodHandler,20)
	srv.fResultMethods = make(map[string]MethodHandler,20)
	srv.fExeWaitMethods = make(map[string]*TcpMethod,20)
	//Hospitals = make(map[string]*HospitalClient,30)
	AppUsers = make(map[string]*AppUser,200)
	srv.LimitSendPkgCount = 0
	srv.MaxDataBufCount = 500
	srv.SetCoder(&CmdCoder{})
	registerMethods(srv)
	srv.OnClientConnect = func(con *DxTcpServer.DxNetConnection) {
		//Common.DebuginfoLog("[Debug]","有客户端连接！：",con.RemoteAddr())
		fmt.Println("有客户端连接！：",con.RemoteAddr())
		//p := make(map[string]interface{})
		//p["id"] = "sdfsdfsdfsdfsdf"
	//	srv.ExecuteMethod(con,"addfriend",nil)
	}

	srv.OnClientDisConnected = func(con *DxTcpServer.DxNetConnection) {
		data := con.GetUseData()
		con.SetUseData(nil)
		if data != nil{
			switch data.(type) {
		//	case *HospitalClient:
		//		(data).(*HospitalClient).con = nil
			case *AppUser:
				(data).(*AppUser).con = nil
			}
		}
	}

	//接收数据的时候处理
	srv.OnRecvData = func(con *DxTcpServer.DxNetConnection,recvData interface{}){
		//Common.DebuginfoLog("[Debug]","有客户端消息：",con.RemoteAddr())
		methodpkg := recvData.(*TcpMethod)
		fmt.Println("有客户端消息：",con.RemoteAddr(),methodpkg.Method.Name)
		defer func(){
			if err := recover();err!=nil{
				if Common.ServiceConfig.DebugLog && Common.Logger != nil{
					switch methodpkg.Type {
					case Common.RP_Result:
						Common.DebuginfoLog("[Error]",fmt.Sprintf("执行向远程请求函数“%s”之后，获的返回结果发生异常：%v",methodpkg.Method.Name,err))
					case Common.RP_Method:
						Common.DebuginfoLog("[Error]",fmt.Sprintf("执行远程请求函数“%s”，发生异常：%v",methodpkg.Method.Name,err))
					case Common.RP_Notify:
						Common.DebuginfoLog("[Error]",fmt.Sprintf("执行远程请求通知函数“%s”，发生异常：%v",methodpkg.Method.Name,err))
					}
				}
				freeMethod(methodpkg)
			}
		}()
		if methodpkg.Type==Common.RP_Result{ //是自己请求的方法，返回的结果
			srv.RLock()
			runmethod ,ok := srv.fExeWaitMethods[methodpkg.Method.ID]
			resulthandler,hashandler := srv.fResultMethods[methodpkg.Method.Name]
			srv.RUnlock()
			if hashandler {//执行自己的请求的返回结果处理函数
				resulthandler(con,methodpkg)
			}
			if ok {
				if runmethod.fWaitchan!=nil{
					runmethod.fWaitchan <- struct{}{}
				}
				srv.Lock()
				delete(srv.fExeWaitMethods,runmethod.Method.ID)
				srv.Unlock()
			}
			freeMethod(methodpkg)
			return
		}
		srv.RLock()
		handler,ok := srv.fmethods[methodpkg.Method.Name]
		srv.RUnlock()
		if ok{
			handler(con,methodpkg)
			if methodpkg.Type == Common.RP_Notify{//通知，不用返回的
				return
			}
			if methodpkg.fWriteBack{
				methodpkg.Method.Params = nil
				methodpkg.Type = Common.RP_Result //作为结果返回
				con.WriteObject(methodpkg) //发送结果回去
			}
		}else{
			if Common.ServiceConfig.DebugLog && Common.Logger != nil && methodpkg.Method.Name != "SendHeart"{
				fmt.Println("未处理的请求函数：",methodpkg.Method.Name)
				con.WriteObject(methodpkg) //发送结果回去
				Common.DebuginfoLog("[Debug]","未处理的请求函数：",methodpkg.Method.Name)
			}
			freeMethod(methodpkg)
		}

	}

	srv.OnSendData = func(con *DxTcpServer.DxNetConnection,Data interface{},sendlen int,sendok bool){
		//回收结果数据
		resultpkg := Data.(*TcpMethod)
		if resultpkg.Method.Name == "OtherClientLogin"{
			//关闭这个连接
			con.Close()
		}
		if resultpkg.fWaitchan == nil {
			freeMethod(resultpkg)
		}
	}
	srv.Open(Common.ServiceConfig.Tcp.ServerAddr)
	return srv
}

