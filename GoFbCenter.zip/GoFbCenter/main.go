package main

import (
	"github.com/suiyunonghen/GVCL/Components/Controls"
	"github.com/suiyunonghen/GVCL/Components/NVisbleControls"
	"github.com/suiyunonghen/GVCL/WinApi"
	"unsafe"
	"syscall"
	"fmt"
	"time"
	"GoFbCenter/Common"
	"GoFbCenter/DBOperate"
	//"GoFbCenter/HttpService"
	"GoFbCenter/TcpService"
)

func main()  {
	app := controls.NewApplication()
	app.ShowMainForm = false
	httpport := Common.ServiceConfig.HttpPort()
	mainForm := app.CreateForm()
	PopMenu := NVisbleControls.NewPopupMenu(mainForm)
	mitems := PopMenu.Items()
	mItem := mitems.AddItem("服务信息")
	mItem.OnClick = func(sender interface{}) {
		//通过网页返回服务端消息
		WinApi.ShellExecute(mainForm.GetWindowHandle(),uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr("OPEN"))),
			uintptr(unsafe.Pointer(syscall.StringToUTF16Ptr(fmt.Sprintf("http://127.0.0.1%s/Fbxts/srvInfo",httpport)))),0,0,WinApi.SW_SHOWNORMAL)
	}

	mItem = mitems.AddItem("-")
	mItem =mitems.AddItem("退出")
	mItem.OnClick = func(sender interface{}) {
		mainForm.Close()
	}

	DBOperate.DbOp = DBOperate.NewDbOp()
	DBOperate.DbOp.Open()

	trayicon := NVisbleControls.NewTrayIcon(mainForm)
	trayicon.PopupMenu = PopMenu
	trayicon.SetVisible(true)
	//HttpService.InitService()
	srv := TcpService.InitService()

	Common.ServerStartTime = time.Now().Format("2006-01-02 15:04:05")
	defer func() {
		DBOperate.DbOp.Close()
		close(Common.Quit)
		srv.Close()
		Common.CloseLog() //关闭日志
	}()
	app.Run()
}
