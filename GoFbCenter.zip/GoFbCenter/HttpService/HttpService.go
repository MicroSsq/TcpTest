package HttpService

import (
	"github.com/buaazp/fasthttprouter"
	"github.com/valyala/fasthttp"
	"GoFbCenter/Common"
	"GoFbCenter/TcpService"
	"fmt"
	"sync"
	"github.com/json-iterator/go"
	"GoFbCenter/DBOperate"
	"sort"
	"time"
	"bytes"
	"crypto/md5"
	"strings"
	"encoding/hex"
	"github.com/landjur/golibrary/errors"
	"math/rand"
	"sync/atomic"
	"github.com/suiyunonghen/DxTcpServer"
)


type(
	HttpResponseResult			struct {
		Response			string 	`json:"response"`
		UserInfo			interface{}	`json:"userInfo"`
		Err					string
	}

	ArgValue struct {
		Name			string
		Value			string
	}

	uMobileVCode	struct {
		PhoneNum		string
		VCode			string
		CodeTime		time.Duration
	}
)

var(
	responseResPool			sync.Pool
	httpclientPool	  		sync.Pool
	vcodePool				sync.Pool
	gMobileVCodes			map[string]*uMobileVCode			//存放用户手机和验证码
	fHasInitMobileCheck		int32
	mobilecodeMutex			sync.RWMutex
)

const(
	alidayAppKey	string="23489355" //大鱼的APPkey
	alidayApp_Secret = "7c6c3f546f3c540734a56566828bb39a"

)

func getVcode(phone string)*uMobileVCode  {
	ret := vcodePool.Get()
	var vcode *uMobileVCode
	if ret == nil{
		vcode = new(uMobileVCode)
	}else{
		vcode = ret.(*uMobileVCode)
	}
	vcode.PhoneNum = phone
	return vcode
}

func (v *ArgValue)SetArg(Name,Value string)  {
	v.Name = Name
	v.Value = Value
}

//通过阿里大于发送短信验证码
func SendSmsVCode(Vcode, PhoneNum string) error {
	m := httpclientPool.Get()
	var httpclient *fasthttp.Client
	if m == nil{
		httpclient = new(fasthttp.Client)
	}else{
		httpclient = m.(*fasthttp.Client)
	}
	req := fasthttp.AcquireRequest()
	resp := fasthttp.AcquireResponse()
	defer func(){
		fasthttp.ReleaseRequest(req)
		fasthttp.ReleaseResponse(resp)
	}()
	req.SetRequestURI(`https://eco.taobao.com/router/rest`)
	req.Header.SetMethodBytes([]byte("POST"))
	req.Header.SetContentType("application/x-www-form-urlencoded")
	//构建参数
	args := make([]ArgValue,12)
	args[0].SetArg("app_key",alidayAppKey)
	args[1].SetArg("format","json")
	args[2].SetArg("method","alibaba.aliqin.fc.sms.num.send")
	args[3].SetArg("sign_method","md5")
	args[4].SetArg("timestamp",time.Now().Format("2006-01-02 15:04:05"))
	args[5].SetArg("v","2.0")
	args[6].SetArg("sms_type","normal")
	args[7].SetArg("sms_free_sign_name","飞博科技")
	args[8].SetArg("rec_num",PhoneNum)
	args[9].SetArg("sms_template_code","SMS_25340184")
	args[10].SetArg("sms_param",fmt.Sprintf(`{"name":"%s","code":"%s"}`,PhoneNum,Vcode))
	//计算签名
	//排序
	sort.Slice(args[:11],func(i, j int) bool{
		return args[i].Name < args[j].Name
	})
	bufer := bytes.NewBuffer(make([]byte,0,256))
	bufer.WriteString(alidayApp_Secret)
	for idx,v := range args{
		bufer.WriteString(v.Name)
		bufer.WriteString(v.Value)
		if idx == 10{
			break
		}
	}
	bufer.WriteString(alidayApp_Secret)
	md5hash := md5.New()
	md5hash.Write(bufer.Bytes())
	args[11].SetArg("sign",strings.ToUpper(hex.EncodeToString(md5hash.Sum(nil)))) //签名
	//合并成提交的串
	bufer.Reset()
	for idx,v := range args{
		if idx > 0{
			bufer.WriteByte('&')
		}
		bufer.WriteString(v.Name)
		bufer.WriteByte('=')
		bufer.WriteString(v.Value)
	}
	req.AppendBody(bufer.Bytes())
	bufer.Reset()
	if err := httpclient.Do(req,resp);err!=nil{
		return err
	}
	result := make(map[string]interface{})
	if err := jsoniter.Unmarshal(resp.Body(),&result);err!=nil{
		return err
	}
	if v,ok := result["alibaba_aliqin_fc_sms_num_send_response"];ok{
		switch v.(type){
		case map[string]interface{}:
			mv := v.(map[string]interface{})
			if vret,ok := mv["result"];ok{
				switch vret.(type) {
				case map[string]interface{}:
					result = vret.(map[string]interface{})
					if len(result)==0{
						return nil
					}else{
						if b,ok := result["success"];ok{
							switch b.(type) {
							case bool:
								if !b.(bool){
									return errors.New("执行失败")
								}
							case string:
								if strings.ToUpper(b.(string)) != "TRUE"{
									return errors.New("执行失败")
								}
							}
						}else{
							return errors.New("执行失败")
						}
					}
				case map[interface{}]interface{}:

				}
			}
		}
	}else if errv,eok := result["error_response"];eok{
		switch errv.(type) {
		case map[string]interface{}:
			ev := errv.(map[string]interface{})
			msginfo,ok := ev["sub_msg"]
			if ok{
				return errors.New(msginfo.(string))
			}
			if msginfo,ok = ev["msg"];ok{
				return errors.New(msginfo.(string))
			}
		case map[interface{}]interface{}:

		case map[string]string:

		}
	}else{
		return errors.New("异常的返回")
	}
	return nil
}

func getResponseResult(responseName string)*HttpResponseResult  {
	result := responseResPool.Get()
	var ret *HttpResponseResult
	if result == nil {
		ret = new(HttpResponseResult)
	}else{
		ret = result.(*HttpResponseResult)
	}
	ret.Response = responseName
	return ret
}

func freeResponseResult(result *HttpResponseResult){
	result.Err = ""
	result.Response = ""
	result.UserInfo = nil
	responseResPool.Put(result)
}

//根据手机号，生成6位验证码
func GetMobileVCode(Phone string)string  {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	bufer := bytes.NewBuffer(make([]byte,0,6))
	rs := []rune(Phone)
	for idx := len(rs) - 1;idx>4;idx--{
		k := r.Intn(int(rs[idx])) % 36
		if k<10 {
			bufer.WriteByte(byte(48+k))
		}else{
			bufer.WriteByte(byte(65+k-10))
		}
	}
	return bufer.String()
}

//注册
func userRegister(ctx *fasthttp.RequestCtx)  {
	args := ctx.PostArgs()
	var username, password,PhoneNum,VCode string
	bt := args.Peek("PhoneNum")
	if bt != nil{
		PhoneNum = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"register","Err":"请指定有效的手机号"}`)
		return
	}

	dbresult,err := DBOperate.DbOp.GetSqlValue(fmt.Sprintf(`select U_LoginID from T1_user where U_LoginID='%s'`,PhoneNum),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"register","Err":"查询数据失败：%s"}`,err.Error()))
		return
	}else if dbresult!=nil{
		fmt.Fprint(ctx,`{"response":"register","Err":"指定的手机号已经被注册了！"}`)
		return
	}

	mobilecodeMutex.RLock()
	mobileCode,ok := gMobileVCodes[PhoneNum]
	if !ok{
		mobilecodeMutex.RUnlock()
		fmt.Fprint(ctx,`{"response":"register","Err":"验证码已经过期，请重新获取验证码信息！"}`)
		return
	}
	mobilecodeMutex.RUnlock()

	bt = args.Peek("VCode")
	if bt != nil{
		VCode = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"register","Err":"请指定有效的验证码"}`)
		return
	}

	if mobileCode.VCode != VCode{
		fmt.Fprint(ctx,`{"response":"register","Err":"验证码不匹配，请重新指定有效的验证码！"}`)
		return
	}
	mobilecodeMutex.Lock()
	delete(gMobileVCodes,PhoneNum)
	mobilecodeMutex.Unlock()

	bt = args.Peek("password")
	if bt != nil{
		VCode = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"register","Err":"请指定有效的用户密码"}`)
		return
	}

	bt = args.Peek("username")
	if bt != nil{
		username = Common.FastByte2String(bt)
	}
	//获取用户ID
	dbresult,err = DBOperate.DbOp.GetSqlValue(`select dbo.GetUserNo() as UID`,"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"register","Err":"获取生成用户ID失败：%s"}`,err.Error()))
		return
	}
	uid := dbresult["UID"].(string)
	err = DBOperate.DbOp.ExecuteSql(`Insert T1_User(U_USERID,U_LoginID,U_PassWord,U_NickName,U_Name) Values(?,?,?,?)`,"",
		uid,PhoneNum,password,username,username)
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"register","Err":"注册用户失败：%s"}`,err.Error()))
		return
	}
	//注册成功
	//加入用户列表中去
	//appuser  := new(TcpService.XtAppUser)
	//appuser.Name = username
	//appuser.LoginId = PhoneNum
	//appuser.PWd = password
	//appuser.UserId = uid
	//TcpService.GlobalMutx.Lock()
	//TcpService.AppUsers[PhoneNum] = appuser
	//TcpService.GlobalMutx.Unlock()
	//fmt.Fprint(ctx,fmt.Sprintf(`{"response":"register","userInfo":{"userid":"%s"}}`,uid))
	//注册成功，默认进入登录状态
}

func checkMobileVcode()  {
	for{
		select {
		case <-DxTcpServer.After(time.Minute*10):
			//每10分钟查一次
			unixseconds := time.Now().Unix()
			mobilecodeMutex.Lock()
			for PhoneNum,v := range gMobileVCodes{
				if PhoneNum!=v.PhoneNum || v.VCode=="" || time.Duration(unixseconds) - v.CodeTime >= time.Minute * 22{
					delete(gMobileVCodes, PhoneNum)
				}
			}
			mobilecodeMutex.Unlock()
		case <-Common.Quit:
			return
		}
	}
}

func getMobileMsg(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	bt := args.Peek("PhoneNum")
	if bt == nil{
		fmt.Fprint(ctx,`{"response":"GetMobileMsg","Err":"请指定一个有效的手机号"}`)
		return
	}
	PhoneNum := Common.FastByte2String(bt)
	vcode := GetMobileVCode(PhoneNum)
	//发送验证码
	if err := SendSmsVCode(vcode,PhoneNum);err!=nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"发送验证码失败：%s"}`,err.Error()))
		mobilecodeMutex.Lock()
		if _,ok := gMobileVCodes[PhoneNum];ok{
			delete(gMobileVCodes, PhoneNum)
		}
		mobilecodeMutex.Unlock()
		return
	}
	//增加到用户验证码中，验证码在30分钟内有效
	mobilecodeMutex.Lock()
	mvcode,ok := gMobileVCodes[PhoneNum]
	if !ok{
		mvcode = getVcode(PhoneNum)
		gMobileVCodes[PhoneNum] = mvcode
	}
	mvcode.VCode = vcode
	mvcode.CodeTime = time.Duration(time.Now().Unix()) //秒
	mobilecodeMutex.Unlock()
	fmt.Fprint(ctx,`{"response":"GetMobileMsg"}`)
	if atomic.LoadInt32(&fHasInitMobileCheck) == 0{
		atomic.StoreInt32(&fHasInitMobileCheck,1)
		go checkMobileVcode()
	}
}

//登录
func userLogin(ctx *fasthttp.RequestCtx)  {
	var args *fasthttp.Args
	if string(ctx.Request.Header.Method()) == "POST"{
		args = ctx.PostArgs()
	}else{
		args = ctx.QueryArgs()
	}
	logid := ""
	pwd := ""
	bt := args.Peek("username")
	if bt!=nil {
	   	logid = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的登录信息"}`)
		return
	}
	bt = args.Peek("password")
	if bt != nil{
		pwd = Common.FastByte2String(bt)
	}
	mobilecodeMutex.Lock()
	appuser,ok := TcpService.AppUsers[logid]
	if ok{
		mobilecodeMutex.Unlock()
		if appuser.PWd != pwd{
			fmt.Fprint(ctx,`{"response":"login","Err":"用户密码无效"}`)
			return
		}
	}else{
		//不存在
		dbresult,err := DBOperate.DbOp.GetSqlValue(fmt.Sprintf("select U_USERID,U_LoginID,U_PassWord from T1_user where U_LoginID='%s'",logid),"")
		if err != nil{
			mobilecodeMutex.Unlock()
			fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
			return
		}else if dbresult == nil{
			mobilecodeMutex.Unlock()
			fmt.Fprint(ctx,`{"response":"login","Err":"指定的用户不存在"}`)
			return
		}
		appuser = new(TcpService.XtAppUser)
		appuser.PWd = dbresult["U_PassWord"].(string)
		appuser.LoginId = logid
		appuser.UserId = dbresult["U_USERID"].(string)
		TcpService.AppUsers[logid] = appuser
		mobilecodeMutex.Unlock()
		if appuser.PWd != pwd{
			fmt.Fprint(ctx,`{"response":"login","Err":"用户密码无效"}`)
			return
		}
	}
	ret := getResponseResult("login")
	ret.Err = ""
	uinfo := make(map[string]string,1)
	uinfo["userid"] = appuser.UserId
	ret.UserInfo = uinfo
	bt,_ = jsoniter.Marshal(ret)
	freeResponseResult(ret)
	fmt.Fprint(ctx,Common.FastByte2String(bt))
}

//获取用户信息
func userdata(ctx *fasthttp.RequestCtx)  {
	var args *fasthttp.Args
	if string(ctx.Request.Header.Method()) == "POST"{
		args = ctx.PostArgs()
	}else{
		args = ctx.QueryArgs()
	}
	Uid := ""
	bt := args.Peek("Uid")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T1_User where U_USERID='%s'`,Uid),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"UserInfo":%s}`,ret))
}

func srvInfo(ctx *fasthttp.RequestCtx)  {
	fmt.Fprint(ctx,"这里是服务信息，请在这里做处理")
}

//获取血糖数据
func GetCloudXtData(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	}else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T2_GLUResult_2016_1 with(nolock) where G_USERID='%s'`,Uid),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetCloudXtData":%s}`,ret))

}

//获取胰岛素数据
func GetInsulinList(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxDate := args.Peek("MaxDate")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
 	if MaxDate == nil {
		fmt.Fprint(ctx, "请填写日期！")
		return
	}
	date := string(MaxDate[:]) + " 23:59:59"

	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T2_user_insulin with(nolock) where U_userid='%s' and U_testdatetime <'%s '`,Uid,date),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetInsulinList":%s}`,ret))

}

//获用药信息数据
func GetYaoPLis(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxDate := args.Peek("MaxDate")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	if MaxDate == nil {
		fmt.Fprint(ctx, "请填写日期！")
		return
	}
	date := string(MaxDate[:]) + " 23:59:59"

	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T2_user_drug with(nolock) where  U_userid='%s' and U_testdatetime <'%s '`,Uid,date),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetYaoPLis":%s}`,ret))

}

//获用药信息数据
func GetCloudFoodData(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxID := args.Peek("MaxID")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	if MaxID == nil {
		fmt.Fprint(ctx, "请填写最大编号！")
		return
	}
	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T2_user_food with(nolock) where F_userid='%s' and F_foodID <='%s '`,Uid,string(MaxID[:])),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetCloudFoodData":%s}`,ret))

}

//获取运动记录和生理记录
func GetUserResultList(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxDate := args.Peek("MaxDate")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	if MaxDate == nil {
		fmt.Fprint(ctx, "请填写日期！")
		return
	}
	date := string(MaxDate[:]) + " 23:59:59"

	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select * from T2_users_Result with(nolock) where userid='%s' and testDate <'%s' `,Uid,date),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetUserResultList":%s}`,ret))

}

//获取血压记录
func GetXyResult(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxID := args.Peek("MaxID")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	if MaxID == nil {
		fmt.Fprint(ctx, "请填写最大编号！")
		return
	}

	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select top %s * from T2_users_Xy_Result with(nolock) where userid='%s' `,MaxID,Uid),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"GetXyResult":%s}`,ret))

}

//获取检验单记录
func Getusersjyd(ctx *fasthttp.RequestCtx)  {
	args := ctx.QueryArgs()
	Uid := ""
	bt := args.Peek("Uid")
	MaxID := args.Peek("MaxID")
	if bt!=nil {
		Uid = Common.FastByte2String(bt)
	} else{
		fmt.Fprint(ctx,`{"response":"login","Err":"请指定一个有效的用户ID信息"}`)
		return
	}
	if MaxID == nil {
		fmt.Fprint(ctx, "请填写最大编号！")
		return
	}

	ret,err := DBOperate.DbOp.DataSet2Json(fmt.Sprintf(`select top %s * from T2_users_jyd with(nolock) where userid='%s' `,MaxID,Uid),"")
	if err != nil{
		fmt.Fprint(ctx,fmt.Sprintf(`{"response":"login","Err":"%s"}`,err.Error()))
		return
	}
	fmt.Fprint(ctx,fmt.Sprintf(`{"Getusersjyd":%s}`,ret))

}


func InitService()  {
	router := fasthttprouter.New()
	router.POST("/Fbxts/register", userRegister)//注册
	router.GET("/Fbxts/srvInfo",srvInfo) //服务信息
	router.GET("/FbXts/GetMobileMsg",getMobileMsg) //获得短信验证码

	router.POST("/Fbxts/login", userLogin)//登录
	router.GET("/Fbxts/login", userLogin)//登录

	router.GET("/Fbxts/userdata", userdata)//查询用户数据
	router.POST("/Fbxts/userdata", userdata)//查询用户数据

	//add yz
	router.GET("/Fbxts/GetCloudXtData", GetCloudXtData)//查询血糖记录
	router.GET("/Fbxts/GetInsulinList",GetInsulinList) //获取胰岛素记录
	router.GET("/Fbxts/GetYaoPLis",GetYaoPLis) //获取用药记录
	router.GET("/Fbxts/GetCloudFoodData",GetCloudFoodData) //获取饮食记录
	router.GET("/Fbxts/GetUserResultList",GetUserResultList) //获取运动记录和生理记录
	router.GET("/Fbxts/GetXyResult",GetXyResult) //获取血压记录
	router.GET("/Fbxts/Getusersjyd",Getusersjyd) //获取检验单记录
	go fasthttp.ListenAndServe(Common.ServiceConfig.Http.ServerAddr, router.Handler)
}
